#include <iostream>
#include "LaysEggsNotBroodly.h"

void LaysEggsNotBroodly::eggs() {
    std::cout << "Lays eggs and will give them up if fed." << std::endl;
}