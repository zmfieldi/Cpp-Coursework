#include <iostream>
#include "LaysToyEggs.h"

void LaysToyEggs::eggs() {
    std::cout << "Lays toy Eggs." << std::endl;
}