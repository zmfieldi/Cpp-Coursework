#ifndef PECKINDUCK_H_
#define PECKINDUCK_H_
#include "Duck.h"
#include "FlyBehavior.h"
#include "QuackBehavior.h"
#include "LaysEggs.h"

class PekinDuck : public Duck { 
public:
   PekinDuck( );
   void display( );
};
#endif /* REDHEADDUCK_H_ */
