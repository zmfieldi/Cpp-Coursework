#ifndef LAYSEGGSNOTBROODLY_H_
#define LAYSEGGSNOTBROODLY_H_
#include "LaysEggs.h"

class LaysEggsNotBroodly : public LaysEggs {
    public:
    void eggs();
};

#endif /* LAYSEGGSNOTBROODLY_H_*/
