#ifndef LAYSTOYEGGS_H_
#define LAYSTOYEGGS_H_
#include "LaysEggs.h"

class LaysToyEggs : public LaysEggs {
    public:
    void eggs();
};

#endif /* LAYSTOYEGGS */