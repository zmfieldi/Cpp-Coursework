#ifndef LAYSEGGSBROODLY_H_
#define LAYSEGGSBROODLY_H_
#include "LaysEggs.h"

class LaysEggsBroodly : public LaysEggs {
    public:
    void eggs();
};

#endif /* LAYSEGGSBROODLY_H_*/
