#ifndef FLYSPOORLY_H_
#define FLYSPOORLY_H_
#include "FlyBehavior.h" 

class FlysPoorly : public FlyBehavior {
    public:
    void fly();
};

#endif /* FLYSPOORLY_H_ */ 