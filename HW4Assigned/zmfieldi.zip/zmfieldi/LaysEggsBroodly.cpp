#include <iostream>
#include "LaysEggsBroodly.h"

void LaysEggsBroodly::eggs() {
    std::cout << "Lays eggs, but will fight you for them." << std::endl;
}