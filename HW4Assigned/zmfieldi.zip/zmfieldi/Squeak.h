#ifndef SQUEAK_H_
#define SQUEAK_H_
#include "QuackBehavior.h"

class Squeak : public QuackBehavior {
public:
   void quack( );
};
#endif /* SQUEAK_H_ */
