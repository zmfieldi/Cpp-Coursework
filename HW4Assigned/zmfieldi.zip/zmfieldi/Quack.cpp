#include <iostream>
#include "Quack.h"

void Quack::quack( ) {
   std::cout << "Quack, quack!" << std::endl;
}
