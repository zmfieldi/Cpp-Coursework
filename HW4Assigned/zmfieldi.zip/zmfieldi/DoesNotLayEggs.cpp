#include <iostream>
#include "DoesNotLayEggs.h"

void DoesNotLayEggs::eggs() {
    std::cout << "Not an egg layer." << std::endl;
}